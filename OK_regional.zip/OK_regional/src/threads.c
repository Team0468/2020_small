#include <kipr/botball.h> 
#include <main_functions.h>
#include <threads.h>
#include <variables.h>
#include <run_sections.h>

void lift_arm_up(){
    servo(arm,arm_block+13,fast);//was +120 now original block height
}
void lower_arm(){
    msleep(1500);
    servo(arm,arm_min,fast);
}
void lower_arm2(){
    servo(arm,arm_min,fast);
}
void raise_arm(){
    servo(arm,arm_max,fast);
}
void big_block(){
	servo(arm,arm_bigblock,slow+1);   
}
void claw_open(){
    msleep(1850);
    servo(claw,claw_max,fast);
}
void claw_close_pull(){
    msleep(500);
    servo(claw,claw_min,slow);
}
void lower_arm_2(){
 servo(arm,arm_min,fast);   
}
void claw_open2(){
    servo(claw,claw_max,fast);
}
void big_block2(){
    servo(arm,arm_bigblock,slow);
}
void arm_water(){
    msleep(400);
    servo(arm,arm_max,slow+1);
    
}
void arm_water2(){
    servo(arm,959,slow);
}
void claw_waterC(){
    servo(claw,claw_min+15,slow);
}
void block_raise(){
    msleep(800);
    servo(arm,arm_block+70,slow);
}
void block_lower(){
   
    servo(arm,arm_min+358,slow+1);
}
void coupler_lower(){
 servo(arm,arm_min+550,slow+1);   
}
void claw_fast(){
 servo(claw,claw_min,fast);   
}
void arm_minecart(){
 servo(arm,arm_max,slow);   
}
void arm_max_fast(){
 servo(arm,arm_max,slow+1);   
}
void micro_close(){
    while(block1 != 1){
     servo(arm_carry,carry_max-50,fast);
        msleep(20);
    }
}
//all thread functions for main and seperate voids and int's