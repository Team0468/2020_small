#include <kipr/botball.h> 
#include <main_functions.h>
#include <threads.h>
#include <variables.h>
#include <run_sections.h>
#include <timer.h>
//time/sections of the run as a whole for ease of finding the section desired

////////////////////////////
#define back  (-85)		  //	back claw and lowering motor speeds
#define forward 85 		  //
////////////////////////////

////////////////////////////
int stop, back_claw = 0;  //	both stop for motors and back claw are the value 0 so we declare both 
////////////////////////////

////////////////////////////
int left_motor_move();    //	movement functions for back physical square and affectors declared
int right_motor_move();   //
int back_arm_move();      //
int hand();               //
////////////////////////////

////////////////////////////
int back_port =3;		  //	physical sensor port declaration
int back_bound = 5;       //
////////////////////////////

////////////////////////////
int down = .5*back;	 	  //	variable to run at half speed when lowering back arm specifically
////////////////////////////

//////////////////////////////////////////////////////////////////////////////
/// extraction() begins in the starting box									//
/// facing the beginning of the ramp in line with the first yellow cube		//
/// extraction() ends after the first yellow cube is lifted					//
//////////////////////////////////////////////////////////////////////////////

int extraction()
{
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    																										  //
    reset_timer(5);		//reset timer to only run for certain time											  //
    while (digital(left_motor) ==0 || digital(right_motor)==0){//original									  //
        digital(left_motor)==0 ? left_motor_move(back) : left_motor_move(stop);								  //	back physical square
        digital(right_motor)==0 ? right_motor_move(back) : right_motor_move(stop);							  //
      if(timer(5)> 1){break;}	//case to break after timer reachs 1										  //																		
    }																										  //
    																										  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
////////////////////////////
    move(600,600); 		  //
    msleep(150);		  //	adjustment for where the blocks are placed on comp day
    stop_1();			  //
////////////////////////////
    
//////////////////////////////////////////////////////////
    while ( digital ( back_port ) == 0 ){//dropping arm //
        												//
        if ( digital( back_port ) == 0 ){				//
            motor( back_port , back );// drops arm		//
        }												//	puts arm in position to grab yellow block
        												//
        else if ( digital( back_port ) == 1 ){          //
            break;		//this is for when back clicker //
        }				//is clicked meaning arm is down//
        												//
    }													//
    off(back_port); //stops so we dont kill the clicker //
//////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////////////
    cmpc(back_claw);	//clear position so we read ticks correctly				//
    reset_timer(1);		//reset for timer 										//
    while ( gmpc( back_claw ) < 250 && timer(1) < 1 ){//closing back claw		//
																				//		close on yellow
        hand(down*( -1 ));//close claw function									//
																				//
    }																			//
    hand( stop );	//hold claw while we lift 									//
//////////////////////////////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////////
    cmpc( back_port );	//clear position so we read ticks correctly			//
    reset_timer( 2 );	//reset for timer									//
    																		//
    while( analog( back_bound ) < 2000 && timer( 2 ) < 1){					//
        																	//
        back_arm_move(forward);	//lift arm									//		lift arm w/ yellow
																			//
    }																		//
    																		//
    back_arm_move(stop);	//stops arm										//
    off(back_port);			//turns both off other wise it interfears		//
	off(back_claw);			//with driving and other functions				//
//////////////////////////////////////////////////////////////////////////////
    
    return water_contain();   //returns the next portion of the code
    
}
//////////////////////////////////////////////////////////////////////////////////
/// extraction_2() begins at the extraction of the second yellow cube			//
/// facing the middle of the ramp in line with the second yellow cube			//
/// while extraction_2() is happening the other claw is holding 2 green cubes	//
/// extraction_2() ends at the second extraction of the big yellow cube			//
//////////////////////////////////////////////////////////////////////////////////

int extraction_2()
{
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    																										  //
    reset_timer(5);		//reset timer to only run for certain time											  //
    while (digital(left_motor) ==0 || digital(right_motor)==0){//original									  //
        digital(left_motor)==0 ? left_motor_move(back) : left_motor_move(stop);								  //	back physical square
        digital(right_motor)==0 ? right_motor_move(back) : right_motor_move(stop);							  //
      if(timer(5)> 1){break;}	//case to break after timer reachs 1										  //																		
    }																										  //
    																										  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
////////////////////////////
    move(600,600); 		  //
    msleep(150);		  //	adjustment for where the blocks are placed on comp day
    stop_1();			  //
////////////////////////////

//////////////////////////////////////////////////////////
    while ( digital ( back_port ) == 0 ){//dropping arm //
        												//
        if ( digital( back_port ) == 0 ){				//
            motor( back_port , back );// drops arm		//
        }												//	puts arm in position to grab yellow block
        												//
        else if ( digital( back_port ) == 1 ){          //
            break;		//this is for when back clicker //
        }				//is clicked meaning arm is down//
        												//
    }													//
    off(back_port); //stops so we dont kill the clicker //
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////
    cmpc(back_claw);	//clear position so we read ticks correctly				//
    reset_timer(1);		//reset for timer 										//
    while ( gmpc( back_claw ) < 250 && timer(1) < 1 ){//closing back claw		//
																				//
        hand(down*( -1 ));//close claw function									//
																				//
    }																			//
    hand( stop );	//hold claw while we lift 									//
//////////////////////////////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////////
    cmpc( back_port );	//clear position so we read ticks correctly			//
    reset_timer( 2 );	//reset for timer									//
    																		//
    while( analog( back_bound ) < 2000 && timer( 2 ) < 1){					//
        																	//
        back_arm_move(forward);	//lift arm									//
																			//
    }																		//
    																		//
    back_arm_move(stop);	//stops arm										//
    off(back_port);			//turns both off other wise it interfears		//
	off(back_claw);			//with driving and other functions				//
//////////////////////////////////////////////////////////////////////////////
   
    return delivery();	//returns the next portion of the code

}
//////////////////////////////////////////////////////////////////////////////
// extraction_3() begins at the extraction of the third yellow cube			//
// while extraction_3() is going on the other claw is holding 2 red cubes	//
// facing the end of the ramp in line with the third yellow cube			//
// extraction_3() ends when the yellow cube is lifted               		//                    
//////////////////////////////////////////////////////////////////////////////

int extraction_3()
{
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    																										  //
    reset_timer(5);		//reset timer to only run for certain time											  //
    while (digital(left_motor) ==0 || digital(right_motor)==0){//original									  //
        digital(left_motor)==0 ? left_motor_move(back) : left_motor_move(stop);								  //	back physical square
        digital(right_motor)==0 ? right_motor_move(back) : right_motor_move(stop);							  //
      if(timer(5)> 1){break;}	//case to break after timer reachs 1										  //																		
    }																										  //
    																										  //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
////////////////////////////
    move(600,600); 		  //
    msleep(150);		  //	adjustment for where the blocks are placed on comp day
    stop_1();			  //
////////////////////////////

//////////////////////////////////////////////////////////
    while ( digital ( back_port ) == 0 ){//dropping arm //
        												//
        if ( digital( back_port ) == 0 ){				//
            motor( back_port , back );// drops arm		//
        }												//	puts arm in position to grab yellow block
        												//
        else if ( digital( back_port ) == 1 ){          //
            break;		//this is for when back clicker //
        }				//is clicked meaning arm is down//
        												//
    }													//
    off(back_port); //stops so we dont kill the clicker //
//////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////////////
    cmpc(back_claw);	//clear position so we read ticks correctly				//
    reset_timer(1);		//reset for timer 										//
    while ( gmpc( back_claw ) < 250 && timer(1) < 1 ){//closing back claw		//
																				//		grab yellow
        hand(down*( -1 ));//close claw function									//
																				//
    }																			//
    hand( stop );	//hold claw while we lift 									//
//////////////////////////////////////////////////////////////////////////////////
    
//////////////////////////////////////////////////////////////////////////////
    cmpc( back_port );	//clear position so we read ticks correctly			//
    reset_timer( 2 );	//reset for timer									//
    																		//
    while( analog( back_bound ) < 2000 && timer( 2 ) < 1){					//
        																	//		lift arm w/ yellow
        back_arm_move(forward);	//lift arm									//
																			//
    }																		//
    																		//
    back_arm_move(stop);	//stops arm										//
    off(back_port);			//turns both off other wise it interfears		//
	off(back_claw);			//with driving and other functions				//
//////////////////////////////////////////////////////////////////////////////
    
    return delivery_2();	//returns the next portion of the code
    
}

//////////////////////////////////////////////////////////////////////////
int left_motor_move(int speed){motor(left_motor,speed); return 1;}		//
int right_motor_move(int speed){motor(right_motor,speed); return 1;}	//
int back_arm_move(int speed){motor(back_port,speed); return 1;};		//
int hand(int speed){motor(back_claw,speed); return 1;};					//
																		//
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////
int water_contain(){	//this is after extract1()	//
    move(400,-400);		//heads toward coupler and 	//
   	msleep(225);		//extracts it				//
    stop_1();
    servo(claw,claw_min+700,fast);		//////////////////////////////
    stop_1();
    Drive(3000,80);	//drive to coupler	
    stop_1();
    
    move1("d",square,black,1000);	//continue driving?
    stop_1();
    
    move(800,800);
    msleep(600);	//move in to grab
    move(0,700);
    msleep(550);
    stop_1();
    
    servo(claw,claw_min,slow+1);
    msleep(150);
    stop_1();
    move(1100,400);		//extract
    msleep(1025);
    move(1000,1000);
    msleep(500);

    stop_1();
    square_up(black,-800);//getting to know position
    stop_1();
////////////////////////////////////////////////////////
    
    return place_block_and_go();
}

//////////////////////////////////////////////////////////////////////
int place_block_and_go(){//this is after extracting water contain	//
    					 //delivers yellow block1      				//
    					 /////////////////////////////////////////////

//////////////////////////////////////////////
    thread openc;							//	Thread creates
    	openc = thread_create(claw_open);	//
//////////////////////////////////////////////
    
    thread_start(openc);	//start thread to release water contain
    Drive(-2675,-80);		//drive to box
    stop_1();
    
    turn_with_gyro(1050,-90);
    stop_1();
    Drive(1100,80);		//moving to place position to place
    stop_1();
    
//////////////////////////////////////////////////////////////////////////////////////////
    hand(stop);	//stop hand incase it released a little in transport					//
    																					//
//////////////////////////////////////////////////////////////////////////////			//
    while(digital(back_port) ==0 ){	//condition for lowering arm			//			//		yellow drop 1
        																	//			//
        digital(back_port)==0 ? back_arm_move(down) :back_arm_move(stop);	//			//
    	//^^^^^^^^^^^^^ this is an if statment								//			//
    }																		//			//
    off(back_port);	//stops arm so we dont kill clicky						//			//
//////////////////////////////////////////////////////////////////////////////			//
    																					//
//////////////////////////////////////////////////////////////////////////////////////	//
    cmpc(back_claw);	//reset motor pos											//	//
    reset_timer(3);		//reset timer for argument									//	//
    while(gmpc(back_claw) > -180 && timer(3) < 2 ){	//condition  for claw opening	//	//
        																			//	//
        gmpc(back_claw) > -180 ? hand(back) : off(back_claw);	//Opens claw		//	//
        																			//	//
    }																				//	//		
    																				//	//
    off(back_claw);	//stops claw													//	//
//////////////////////////////////////////////////////////////////////////////////////	//
    																					//
//////////////////////////																//
    move(-600,-600);	//																//
    msleep(500);		//																//
    move(400,400);		//		adjustment so we don't throw the block during lift		//
    msleep(500);		//																//
    stop_1();			//																//
//////////////////////////																//
    																					//
//////////////////////////////////////////////////////////////							//	
    while(analog(back_bound) < 2000){	//raise argument	//							//										
        													//							//
        back_arm_move(forward);   //raise arm				//							//
        													//	raise arm after release	//
    }														//							//
															//							//
    back_arm_move(stop);	//stops then turns off			//							//
    off(back_port);			//								//							//
//////////////////////////////////////////////////////////////							//
 																						//
//////////////////////////////////////////////////////////////////////////////////////////
    square_up(black,1000);	//getting to know position
    
//////////////////////////////
    thread_destroy(openc);	//	thread destroy
//////////////////////////////
    
    return block_2doubleStack();	//moves to next portion of code
    								//can be changed to single stack grab
}

//////////////////////////////////////////////////////////////////////
int block_2doubleStack(){//after delivery of yellow goes to grab	//
    					 //top two medium reds and sets up for 		//
    					 // extract 2								//
    					 /////////////////////////////////////////////
    
//////////////////////////////////////////////////
	thread lift_up1;							//	Thread creates
    	lift_up1 = thread_create(lift_arm_up);	//			
//////////////////////////////////////////////////
    
    stop_1();
    thread_start(lift_up1);			//start thread for pickup
    stop_1();
    
    servo(claw,claw_min+400,fast);	//
    stop_1();
    
    move(-600,600);
    msleep(150);
    stop_1();
    Drive(800,80);
    stop_1();
    servo(claw,claw_min,slow+1);
    stop_1();
    servo(arm,arm_max,fast);
    move(600,-600);
    msleep(150);
    stop_1();
    move(800,800);
    msleep(500);

    stop_1();
    turn_with_gyro(800,90);
    stop_1();
    thread_destroy(lift_up1);
    return extraction_2();
    
}
int block_2andstack(){
    thread lift_up1;
    lift_up1 = thread_create(lift_arm_up);
    stop_1();
    thread_start(lift_up1);
    servo(claw,claw_min+400,fast);
    stop_1();
    move(-600,600);
    msleep(100);
    stop_1();
    Drive(800,80);
    stop_1();
    servo(claw,claw_min,fast);
    stop_1();
    servo(arm,arm_max,fast);
    move(600,-600);
    msleep(100);
    stop_1();
    move1("d",drive,700,80);

    stop_1();
    turn_with_gyro(800,90);
    stop_1();
    thread_destroy(lift_up1);
    return extraction_2();
}
int delivery(){
    thread block;
    block = thread_create(big_block);
    thread raise;
    raise = thread_create(raise_arm);

    move(650,650);
    msleep(1400);
    stop_1();
    turn_with_gyro(800,-90);
    stop_1();
    square_up(black,-600);
    stop_1();
    move(800,800);
    msleep(650);
    stop_1();
//////////////////////////////////////////////////////////////////////////////////////////
    hand(stop);	//stop hand incase it released a little in transport					//
    																					//
//////////////////////////////////////////////////////////////////////////////			//
    while(digital(back_port) ==0 ){	//condition for lowering arm			//			//		yellow drop 1
        																	//			//
        digital(back_port)==0 ? back_arm_move(down) :back_arm_move(stop);	//			//
    	//^^^^^^^^^^^^^ this is an if statment								//			//
    }																		//			//
    off(back_port);	//stops arm so we dont kill clicky						//			//
//////////////////////////////////////////////////////////////////////////////			//
    																					//
//////////////////////////////////////////////////////////////////////////////////////	//
    cmpc(back_claw);	//reset motor pos											//	//
    reset_timer(3);		//reset timer for argument									//	//
    while(gmpc(back_claw) > -180 && timer(3) < 2 ){	//condition  for claw opening	//	//
        																			//	//
        gmpc(back_claw) > -180 ? hand(back) : off(back_claw);	//Opens claw		//	//
        																			//	//
    }																				//	//		
    																				//	//
    off(back_claw);	//stops claw													//	//
//////////////////////////////////////////////////////////////////////////////////////	//
    																					//
//////////////////////////																//
    move(-600,-600);	//																//
    msleep(500);		//																//
    move(400,400);		//		adjustment so we don't throw the block during lift		//
    msleep(500);		//																//
    stop_1();			//																//
//////////////////////////																//
    																					//
//////////////////////////////////////////////////////////////							//	
    while(analog(back_bound) < 2000){	//raise argument	//							//										
        													//							//
        back_arm_move(forward);   //raise arm				//							//
        													//	raise arm after release	//
    }														//							//
															//							//
    back_arm_move(stop);	//stops then turns off			//							//
    off(back_port);			//								//							//
//////////////////////////////////////////////////////////////							//
 																						//
//////////////////////////////////////////////////////////////////////////////////////////
    stop_1();
    thread_start(raise);
    stop_1();
    turn_with_gyro(800,90);
    stop_1();
    turn_with_gyro(800,90);
    stop_1();
    move(800,800);
    msleep(100);
    square_up(black,-800);
    
    stop_1();
    thread_start(block);
    stop_1();
    move(500,100);
    msleep(300);
    stop_1();
    servo(claw,claw_min + 400,2);
   servo(arm,950,fast);
    servo(claw,claw_min,2);
    servo(arm,arm_max,fast);
    move(-900,-900);
    msleep(1200);
    move(300,-300);
    msleep(200);
    stop_1();
    thread_start(block);
    msleep(400);
    stop_1();
    servo(claw,claw_min+400,fast);
    msleep(400);
    servo(arm,arm_max,fast);
    stop_1();
    
    move1("d",square,white,800);


    thread_destroy(raise);

    return blocks_2();
}
int blocks_2(){
    thread lower2;
    	lower2 = thread_create(lower_arm_2);
    thread raise1;
    	raise1 = thread_create(block_raise);
    thread arm_max1;
    	arm_max1 = thread_create(arm_max_fast);
    thread microClose;
    	microClose = thread_create(micro_close);
    
    stop_1();
	turn_with_gyro(800,-90);
    stop_1();
    thread_start(arm_max1);
    move(-600,-600);
    msleep(600);
    stop_1();
    
    turn_with_gyro(800,-90);
    stop_1();
    square_up(black,-800);
    
    
    stop_1();
    
    move(600,-600);
    msleep(350);
    move(500,500);
    msleep(950);
    stop_1();
    servo(arm,arm_block-15,slow+1);
    servo(claw,claw_min,slow);
    stop_1();
    
    servo(claw,claw_min,slow+1);
    servo(arm,arm_block+200,fast);
    
    stop_1();
    move(-600,600);
    msleep(460);
    stop_1();
    
    move1("d",drive,1200,80);
    stop_1();
    servo(arm,arm_min+358,slow+1);
    stop_1();
    move(800,800);
    msleep(800);
    stop_1();
    thread_start(microClose);
    stop_1();
    move(-500,500);
    msleep(50);
    move(500,-500);
    msleep(50);
    stop_1();
    move1("d",drive,990,80);
    stop_1();
    thread_start(raise1);
    move1("d",turn,800,90);
    stop_1();
    
    thread_destroy(arm_max1);
    thread_destroy(raise1);
    thread_destroy(lower2);
    return extraction_3();   
}
int delivery_2(){
    thread lower2;
    lower2 = thread_create(lower_arm_2);
    thread block2;
    block2 = thread_create(big_block2);
    thread copen2;
    copen2 = thread_create(claw_open2);
    thread lower3;
    	lower3 = thread_create(block_lower);
    
    stop_1();
    move(650,650);
    msleep(750);
    stop_1();
    thread_start(lower3);
    turn_with_gyro(600,-90);
    stop_1();
    move(-600,600);
    msleep(370);
    stop_1();
    
    stop_1();
    Drive(-1700,-80);
    stop_1();
    servo(arm,arm_max,fast);
    servo(claw,claw_min,fast);
    move(-400,400);
    msleep(680);
    stop_1();
    move1("d",drive,-1000,-80);
    stop_1();
    move1("d",square,black,-800);
    stop_1();
    move1("d",drive,-800,-80);
    stop_1();
//////////////////////////////////////////////////////////////////////////////////////////
    hand(stop);	//stop hand incase it released a little in transport					//
    																					//
//////////////////////////////////////////////////////////////////////////////			//
    while(digital(back_port) ==0 ){	//condition for lowering arm			//			//		yellow drop 1
        																	//			//
        digital(back_port)==0 ? back_arm_move(down) :back_arm_move(stop);	//			//
    	//^^^^^^^^^^^^^ this is an if statment								//			//
    }																		//			//
    off(back_port);	//stops arm so we dont kill clicky						//			//
//////////////////////////////////////////////////////////////////////////////			//
    																					//
//////////////////////////////////////////////////////////////////////////////////////	//
    cmpc(back_claw);	//reset motor pos											//	//
    reset_timer(3);		//reset timer for argument									//	//
    while(gmpc(back_claw) > -180 && timer(3) < 2 ){	//condition  for claw opening	//	//
        																			//	//
        gmpc(back_claw) > -180 ? hand(back) : off(back_claw);	//Opens claw		//	//
        																			//	//
    }																				//	//		
    																				//	//
    off(back_claw);	//stops claw													//	//
//////////////////////////////////////////////////////////////////////////////////////	//
    																					//
//////////////////////////																//
    move(-600,-600);	//																//
    msleep(500);		//																//
    move(400,400);		//		adjustment so we don't throw the block during lift		//
    msleep(500);		//																//
    stop_1();			//																//
//////////////////////////																//
    																					//
//////////////////////////////////////////////////////////////							//	
    while(analog(back_bound) < 2000){	//raise argument	//							//										
        													//							//
        back_arm_move(forward);   //raise arm				//							//
        													//	raise arm after release	//
    }														//							//
															//							//
    back_arm_move(stop);	//stops then turns off			//							//
    off(back_port);			//								//							//
//////////////////////////////////////////////////////////////							//
 																						//
//////////////////////////////////////////////////////////////////////////////////////////
    servo(arm,arm_max,fast);
    move1("d",square,white,800);
    stop_1();
    move(800,800);
    msleep(300);
    move1("d",turn,800,90);
    stop_1();
    move1("d",turn,800,90);
    stop_1();
    move1("d",square,black,-800);
    thread_start(block2);
    stop_1();
    move(500,0);
    msleep(300);
    move(600,600);
    msleep(500);
    
    stop_1();
    block1 = 1;
    servo(arm_carry,carry_min,fast);
    servo(claw,claw_min+400,slow+1);
    servo(arm,arm_max,fast);

	thread_destroy(lower3);
	thread_destroy(copen2);
    thread_destroy(block2);
    thread_destroy(lower2);
    return water_collect();   
}
int water_collect(){
    thread armU;
    	armU = thread_create(arm_max_fast);
    thread armM;
    	armM = thread_create(arm_minecart);
    thread armL2;
    	armL2 = thread_create(lower_arm2);
    thread copen3;
    	copen3 = thread_create(claw_open2);
    thread arm2;
    	arm2 = thread_create(arm_water);
    thread arm3;
    	arm3 = thread_create(arm_water2);
    thread clawC;
    	clawC = thread_create(claw_waterC);
    thread armcoupler;
    	armcoupler = thread_create(coupler_lower);
    thread clawC2;
    	clawC2 = thread_create(claw_fast);
    thread microClose;
    	microClose = thread_create(micro_close);
	stop_1();
    servo(arm,arm_max,fast);
    servo(claw,claw_min,fast);
    move1("d",square,black,-800);
    stop_1();
    move1("d",turn,800,-45);
    stop_1();
    move(-600,600);
    msleep(250);
    move(600,600);
    msleep(280);
    stop_1();
    servo(arm,arm_min,fast);
    
    move(600,-600);
    msleep(995);
    move(-600,600);
    msleep(250);
    stop_1();
    servo(arm,arm_max,fast+1);
    move1("d",square,black,-800);
    stop_1();
    move1("d",turn,800,90);
    stop_1();
    stop_1();
    msleep(100);
    move1("d",turn,800,90);
    stop_1();
    thread_start(copen3);
    stop_1();
    move1("d",square,black,-800);
    stop_1();
    block1 = 0;
    move1("d",drive,1125,80);
    thread_start(microClose);
    stop_1();
    move1("d",drive,1125,80);
    stop_1();
    thread_start(arm3);
    stop_1();
    thread_start(clawC);
    stop_1();
    move(600,0);
    msleep(600);
    stop_1();
    msleep(650);
    servo(arm,arm_max+50,slow+1);
    stop_1();
    
    move(-600,0);
    msleep(600);
    move1("d",drive,-2000,-80);
    stop_1();
    move1("d",square,black,-800);
    stop_1();
    move1("d",turn,800,90);
    stop_1();
    move1("d",turn,800,90);
    stop_1();
    move1("d",square,black,-800);
    stop_1();
    thread_start(armcoupler);
    move(-600,600);
    msleep(150);
    move(600,600);
    msleep(400);
    block1 = 1;
    thread_destroy(microClose);
    stop_1();
    servo(arm_carry,carry_min,fast);
    servo(claw,claw_min+300,slow);
    servo(arm,arm_max,fast);
    move1("d",square,black,-800);
    stop_1();
    move1("d",turn,800,-90);
    
    stop_1();
    move1("d",turn,800,-90);
    thread_start(armL2);
    stop_1();
    move1("d",square,black,-800);
    servo(claw,claw_max,fast);
    stop_1();
    move1("d",drive,1140,80);
    thread_start(clawC2);
    msleep(450);
    move1("d",drive,-1140,-80);
    stop_1();
    move1("d",square,black,-800);
    stop_1();
    thread_start(armU);
    move1("d",turn,800,-90);
    stop_1();
    move1("d",turn,800,-45);
    stop_1();
    servo(claw,claw_max,fast);
    stop_1();
    thread_start(clawC2);
    move1("d",turn,800,45);
    stop_1();
    move(-250,-250);
    msleep(200);
    stop_1();
    servo(arm,arm_min,fast);
   	move(400,400);
    msleep(900);
    stop_1();
    
    
    stop_1();
    thread_start(armM);
    msleep(300);
    
    move(-500,-500);
    msleep(1400);
    stop_1();
    
    
    
    
    /*move1("d",turn,800,-90);
    
    stop_1();
    move1("d",square,black,800);
    stop_1();
    
    stop_1();
    //servo(claw,claw_max,fast);
    stop_1();
    
    move(-600,-600);
    msleep(800);
    
    stop_1();
    servo(arm,arm_min+50,fast);
    stop_1();
    move(600,600);
    msleep(550);
    stop_1();
    servo(claw,claw_min,slow+1);
    stop_1();
   
    
    
    move(-500,-500);
    msleep(500);
   move1("d",square,black,800);
    move(-900,-400);
    msleep(2800);
    stop_1();
    move(300,900);
    msleep(2250);
    move(800,800);
    msleep(100);
    stop_1();
    thread_start(copen3);
    stop_1();
    thread_start(arm2);
    
    move(-1000,-1000);
    msleep(1000);
    stop_1();
    servo(arm,arm_max-150,slow+1);
    stop_1();
    move(0,800);
    msleep(800);
    
    move(400,400);
    msleep(650);
    stop_1();
    thread_destroy(copen3);
     move(300,300);
    msleep(450);
    thread_start(arm3);
    stop_1();
   
    stop_1();
    thread_start(clawC);
   
    stop_1();
    msleep(1350);
    servo(arm,arm_max,slow);
    stop_1();
    move(400,400);
    msleep(450);
    move(-400,-400);
    msleep(860);
    move(600,-600);
    msleep(550);
    stop_1();
    servo(arm,arm_min+570,fast);
    stop_1();
    
    
    servo(claw,claw_min+300,slow);
    stop_1();
    servo(arm,arm_max-150,fast);
    move(-600,600);
    msleep(100);
    stop_1();
    
    servo(claw,claw_max,fast);
    stop_1();
    move(700,700);
    msleep(1050);
    thread_start(arm3);
    stop_1();
    msleep(200);
    servo(claw,claw_min+30,slow);
    servo(arm,arm_max-150,slow+1);
    stop_1();
    move(-600,-600);
    msleep(1050);
    move(300,-300);
    msleep(300);
    stop_1();
    servo(arm,arm_min+570,slow);
    servo(claw,claw_min+400,slow);
    stop_1();
    servo(arm,arm_max-150,fast);
    servo(claw,claw_max,fast);
    stop_1();
    move(200,700);
    msleep(850);
    stop_1();
    move(800,800);
    msleep(200);
    stop_1();
   servo(arm,arm_max-288,fast);
    servo(claw,claw_min,slow);
    stop_1();
    move(-800,-800);
    msleep(200);
    stop_1();
    move(-200,-700);
    msleep(860);
    move(-600,-600);
    msleep(400);
    stop_1();
    servo(arm,arm_min+570,slow);
    servo(claw,claw_min+400,slow);
    stop_1();
    move(-900,-450);
    msleep(2000);
    stop_1();
    servo(arm,arm_min,2);
    servo(claw,claw_min,slow);
    servo(arm,arm_min,fast);
    
    stop_1();
    move1("d",turn,800,90);
    stop_1();
    move1("d",turn,800,45);
    stop_1();
    
    msleep(100000);*/
    msleep(100000);
    thread_destroy(armU);
    thread_destroy(armM);
    thread_destroy(clawC2);
    thread_destroy(armL2);
    thread_destroy(armcoupler);
    thread_destroy(clawC);
    thread_destroy(arm3);
    thread_destroy(arm2);
    
	return 0;
}