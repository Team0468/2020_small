#include <kipr/botball.h> 
#include <main_functions.h>
#include <threads.h>
#include <variables.h>
#include <run_sections.h>
int main()
{
    
    calibrate_gyro();
   
    //csf_threads();
    //turn_with_gyro(800,90);
    diagnostics();
    starting_pos();
    /*servo(arm,arm_max,fast);
    int n = 0;
    square_up(white,800);
    while(n < 4){
        
        turn_with_gyro(800,90);
        	msleep(500);
        	stop_1();
        
        n = n+1;
    }*/
    
    wait_for_light(4);
    shut_down_in(119);
    extraction();
    
    //water_collect();
   
    //servo(arm,arm_bigblock,fast);
    //servo(claw,claw_min+400,fast);
    //water_collect();
    return 0;
}
