int block_2andstack();
int water_contain();
int water_collect();
int place_block_and_go();
int delivery();
int delivery_2();
int blocks_2();